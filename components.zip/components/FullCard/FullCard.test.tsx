import "@testing-library/jest-dom";
import { render, screen } from "@testing-library/react";
import React from "react";
import MonsterCard from "./FullCard";

describe("MonsterCard tests", () => {
  it("should render AngrySnake monster card with all data", () => {
    render(<MonsterCard type="angrysnake" />);
    const name = screen.getByText(/Angry Snake/i);
    expect(name).toBeInTheDocument();
  });
});
