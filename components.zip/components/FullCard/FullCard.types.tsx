export type FullCardProps = {
  name?: "Player" | "Computer";
  selectedMonster?: MonsterData;
};

export type StyledCardProps = {
  selected: boolean;
};

export type MonsterData = {
  id: string;
  name: string;
  attack: number;
  defense: number;
  hp: number;
  speed: number;
  type: string;
  imageUrl: string;
};
