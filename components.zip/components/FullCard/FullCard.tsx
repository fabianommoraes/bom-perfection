import { FullCardProps } from "./FullCard.types";
import PlaceholderCard from "../Placeholder/Placeholder";
import SelectedMonster from "../SelectedMonster/SelectedMonster";
import { StyledCard } from "./FullCard.styles";

const FullCard = ({ name, selectedMonster }: FullCardProps) => {
  let content = null;

  if (selectedMonster) {
    content = <SelectedMonster selectedMonster={selectedMonster} />;
  } else {
    content = <PlaceholderCard name={name} />;
  }

  return <StyledCard selected={Boolean(selectedMonster)}>{content}</StyledCard>;
};

export default FullCard;
