import React from "react";
import MockData from "./mockdata.json";
import FullCard from "./FullCard";

export default {
  title: "Components/FullCard",
  component: FullCard,
  parameters: {
    layout: "centered"
  }
};

export const PlaceholderPlayer = () => <FullCard name="Player" />;

export const PlaceholderComputer = () => <FullCard name="Computer" />;

export const Monster = () => <FullCard selectedMonster={MockData[3]} />;
