import { Typography } from "@mui/material";
import { StyledCard, MonsterImage, StyledInput } from "./MonsterCard.styles";

import { MonsterCardProps } from "./MonsterCard.types";

const MonsterCard = ({
  id,
  name,
  imageUrl,
  onChange,
  selectedMonster
}: MonsterCardProps) => {
  return (
    <label htmlFor={id}>
      <StyledCard checked={selectedMonster === id}>
        <StyledInput
          className="radio-input"
          type="radio"
          name={name}
          id={id}
          value={id}
          onChange={onChange}
          checked={selectedMonster === id}
        />

        <MonsterImage src={imageUrl} width={137} height={99} alt={name} />
        <Typography variant={"subtitle1"}>{name}</Typography>
      </StyledCard>
    </label>
  );
};

export default MonsterCard;
