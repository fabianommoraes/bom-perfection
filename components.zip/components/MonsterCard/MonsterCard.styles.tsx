import { Card, Input } from "@mui/material";
import { styled } from "@mui/material/styles";
import { StyledCardProps } from "./MonsterCard.types";

import Image from "next/image";

export const MonsterImage = styled(Image)(() => ({
  borderRadius: "7px",
  marginBottom: "7px"
}));

export const StyledCard = styled(Card)<StyledCardProps>(({ checked }) => ({
  padding: "6px",
  cursor: "pointer",
  border: checked ? "1px solid black" : "1px solid transparent",
  "&:hover": {
    border: checked ? "1px solid black" : "1px solid #10782E"
  }
}));

export const StyledInput = styled("input")(() => ({
  display: "none"
}));
