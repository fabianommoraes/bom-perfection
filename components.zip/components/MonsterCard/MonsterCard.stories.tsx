import React from "react";

import MonsterCard from "./MonsterCard";

export default {
  title: "Components/MonsterCard",
  component: MonsterCard,
  parameters: {
    layout: "centered"
  }
};

export const DeadUnicorn = () => <MonsterCard type="deadunicorn" />;

export const OldShark = () => <MonsterCard type="oldshark" />;

export const RedDragon = () => <MonsterCard type="reddragon" />;

export const RobotBear = () => <MonsterCard type="robotbear" />;

export const AngrySnake = () => <MonsterCard type="angrysnake" />;
