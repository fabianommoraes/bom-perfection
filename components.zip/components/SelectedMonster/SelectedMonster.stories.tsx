import React from "react";

import SelectedMonster from "./SelectedMonster";

export default {
  title: "Components/SelectedMonster",
  component: SelectedMonster,
  parameters: {
    layout: "centered"
  }
};

export const Primary = () => <SelectedMonster />;
