import { Typography, Box } from "@mui/material";
import { Title, StyledBox, Container } from "./ListOfMonsters.styles";
import CircularProgress from "@mui/material/CircularProgress";
import { ListOfMonstersProps } from "./ListOfMonsters.types";
import MonsterCard from "../MonsterCard/MonsterCard";
import { useState, ChangeEvent } from "react";

const ListOfMonsters = ({ arrayOfMonsters }: ListOfMonstersProps) => {
  const [selectedMonster, setSelectedMonster] = useState("");

  const onChange = (event: ChangeEvent<HTMLInputElement>) => {
    setSelectedMonster(event.target.value);
  };

  const isEmpty = arrayOfMonsters.length === 0;

  return (
    <Container>
      <Title>{isEmpty ? "Loading..." : "Select your monster"}</Title>
      <StyledBox>
        {isEmpty ? (
          <CircularProgress />
        ) : (
          <>
            {arrayOfMonsters.map(({ id, name, imageUrl }) => (
              <MonsterCard
                id={id}
                name={name}
                imageUrl={imageUrl}
                onChange={onChange}
                selectedMonster={selectedMonster}
              />
            ))}
          </>
        )}
      </StyledBox>
    </Container>
  );
};

export default ListOfMonsters;
