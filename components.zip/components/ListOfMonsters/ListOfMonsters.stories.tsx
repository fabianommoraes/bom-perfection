import React from "react";

import ListOfMonsters from "./ListOfMonsters";
import MockData from "./mockdata.json";

export default {
  title: "Components/ListOfMonsters",
  component: ListOfMonsters,
  parameters: {
    layout: "centered"
  }
};

export const WithData = () => <ListOfMonsters arrayOfMonsters={MockData} />;

export const Empty = () => <ListOfMonsters arrayOfMonsters={[]} />;
