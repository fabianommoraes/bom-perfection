import { Typography, Box } from "@mui/material";
import { styled } from "@mui/material/styles";

export const Title = styled(Typography)(() => ({
  marginBottom: "14px",
  fontSize: "22px"
}));

Title.defaultProps = {
  variant: "h5"
};

export const StyledBox = styled(Box)(() => ({
  display: "inline-flex",
  flexWrap: "wrap",
  flexDirection: "row",
  gap: "16px",
  marginBottom: "35px",
  justifyContent: "center",
  alignItems: "center"
}));

export const Container = styled(Box)(() => ({
  display: "flex",
  flexDirection: "column",
  justifyContent: "center",
  alignItems: "center"
}));

export const StyledInput = styled("input")(() => ({
  display: "none"
}));

StyledInput.defaultProps = {
  type: "radio"
};
