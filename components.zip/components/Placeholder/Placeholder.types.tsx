export type PlaceHolderProps = {
  name?: "Player" | "Computer";
};
