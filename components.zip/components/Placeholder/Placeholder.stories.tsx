import React from "react";

import Placeholder from "./Placeholder";

export default {
  title: "Components/Placeholder",
  component: Placeholder,
  parameters: {
    layout: "centered"
  }
};

export const Player = () => <Placeholder name="Player" />;

export const Computer = () => <Placeholder name="Computer" />;
