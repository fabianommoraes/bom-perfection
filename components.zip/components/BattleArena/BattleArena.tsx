import { BattleArenaProps } from "./BattleArena.types";
import { StyledBox, StyledButton } from "./BattleArena.styles";
import FullCard from "../FullCard/FullCard";

const BattleArena = ({
  selectedMonster,
  computerMonster
}: BattleArenaProps) => {
  return (
    <StyledBox>
      <FullCard name="Player" selectedMonster={selectedMonster} />
      <StyledButton variant="contained">Start Battle</StyledButton>
      <FullCard name="Computer" selectedMonster={computerMonster} />
    </StyledBox>
  );
};

export default BattleArena;
