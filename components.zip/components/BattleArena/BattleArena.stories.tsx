import React from "react";
import BattleArena from "./BattleArena";
import MockData from "./mockdata.json";

export default {
  title: "Components/BattleArena",
  component: BattleArena,
  parameters: {
    layout: "centered"
  }
};

export const Default = () => <BattleArena />;
export const PlayerSelected = () => (
  <BattleArena selectedMonster={MockData[0]} />
);

export const ComputerSelected = () => (
  <BattleArena selectedMonster={MockData[0]} computerMonster={MockData[1]} />
);
