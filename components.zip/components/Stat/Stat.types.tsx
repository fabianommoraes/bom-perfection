export type StatProps = {
  name: "HP" | "Attack" | "Defense" | "Speed";
  value: number;
};
